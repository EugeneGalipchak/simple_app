package com.example;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MusicService extends Service {
	private static final String TAG = "MusicService";
	// Media Player
	private MediaPlayer mp;

	private final IBinder mBinder = new LocalBinder();

	/**
	 * Local Binder returned when binding with Activity. This binder will return
	 * the enclosing BinderService instance.
	 */
	public class LocalBinder extends Binder {
		/**
		 * Return enclosing BinderService instance
		 */
		MusicService getService() {
			return MusicService.this;
		}
	}
	
	@Override
	public IBinder onBind(Intent intent) {
		return mBinder;
	}

	@Override
	public void onCreate() {
		Toast.makeText(this, "My Service Created", Toast.LENGTH_LONG).show();
		Log.d(TAG, "Service onCreate");
		mp = MediaPlayer.create(this, R.raw.testsong);
		mp.setLooping(true);
	}

	@Override
	public void onDestroy() {
		Toast.makeText(this, "My Service Stopped", Toast.LENGTH_LONG).show();
		Log.d(TAG, "Service onDestroy");
		mp.stop();
	}


	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		int f =  super.onStartCommand(intent, flags, startId);
		Toast.makeText(this, "My Service Started", Toast.LENGTH_LONG).show();
		Log.d(TAG, "Service onStart");
		mp.start();
		return f;
	}

	/**
	 * Public method which can be called from bound clients.
	 *
	 * This method will return Media Player
	 */
	public MediaPlayer getMediaPlayer() {
	       return mp;
	}

}
