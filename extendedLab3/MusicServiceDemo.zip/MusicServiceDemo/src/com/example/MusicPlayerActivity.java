package com.example;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.ToggleButton;

public class MusicPlayerActivity extends Activity implements OnClickListener {

	private static final String TAG = "MusicServiceDemoActivity";
	ToggleButton startStopService;

	// Handler to update UI timer, progress bar etc,.
	private Handler mHandler = new Handler();

	/**
	 * Reference to our bound service.
	 */
	MusicService mService = null;
    boolean isServiceStarted = false;
	private Utilities utils;
	private ImageButton btnPlay;
	private SeekBar songProgressBar;

	/**
	 * Class for interacting with the main interface of the service.
	 */
	private ServiceConnection mConn = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName className, IBinder binder) {
			Log.d(TAG, "Connected to service.");
			mService = ((MusicService.LocalBinder) binder).getService();
		}

		@Override
		public void onServiceDisconnected(ComponentName className) {
			Log.d(TAG, "Disconnected from service.");
			mService = null;
		}
	};

	@Override
	protected void onResume() {
		super.onResume();
		bindService(new Intent(this, MusicService.class), mConn,
				Context.BIND_AUTO_CREATE);
	}

	@Override
	protected void onStop() {
		super.onStop();
		unbindService(mConn);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		startStopService = (ToggleButton) findViewById(R.id.toggleButton1);
		startStopService.setOnClickListener(this);

		btnPlay = (ImageButton) findViewById(R.id.btnPlay);
		songProgressBar = (SeekBar) findViewById(R.id.songProgressBar);

		utils = new Utilities();

		/**
		 * Play button click event plays a song and changes button to pause
		 * image pauses a song and changes button to play image
		 * */
		btnPlay.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (isServiceStarted) {
					// check for already playing
					if (mService.getMediaPlayer().isPlaying()) {
						if (mService.getMediaPlayer() != null) {
							mService.getMediaPlayer().pause();
							// Changing button image to play button
							btnPlay.setImageResource(R.drawable.btn_play);
						}
					} else {
						// Resume song
						if (mService.getMediaPlayer() != null) {
							mService.getMediaPlayer().start();
							// Changing button image to pause button
							btnPlay.setImageResource(R.drawable.btn_pause);
						}
					}
				}

			}
		});

	}

	/**
	 * Background Runnable thread
	 * */
	private Runnable mUpdateTimeTask = new Runnable() {
		public void run() {
			if (isServiceStarted && mService != null && mService.getMediaPlayer() != null) {
				long totalDuration = mService.getMediaPlayer().getDuration();
				long currentDuration = mService.getMediaPlayer()
						.getCurrentPosition();

				// Updating progress bar
				int progress = (int) (utils.getProgressPercentage(
						currentDuration, totalDuration));
				// Log.d("Progress", ""+progress);
				songProgressBar.setProgress(progress);
			}
			// Running this thread after 100 milliseconds
			mHandler.postDelayed(this, 100);
		}
	};

	public void onClick(View src) {
		switch (src.getId()) {
		case R.id.toggleButton1:
			Log.d(TAG, "onClick: toggling srvice");
			if (startStopService.getText().toString().equals("ON")) {
				bindService(new Intent(this, MusicService.class), mConn,
						Context.BIND_AUTO_CREATE);
				mHandler.postDelayed(mUpdateTimeTask, 100);
				// Changing button image to pause button
				btnPlay.setImageResource(R.drawable.btn_pause);
				startService(new Intent(this, MusicService.class));
				isServiceStarted = true;
				
			} else {
				songProgressBar.setProgress(0);
				unbindService(mConn);
				// Changing button image to play button
				btnPlay.setImageResource(R.drawable.btn_play);
				mHandler.removeCallbacks(mUpdateTimeTask);
				mService = null;
				isServiceStarted = false;
				stopService(new Intent(this, MusicService.class));
			}
			break;

		}
	}
}